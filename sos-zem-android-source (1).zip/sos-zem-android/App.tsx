import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Clipboard from "expo-clipboard";
import * as ImagePicker from "expo-image-picker";
import { StatusBar } from "expo-status-bar";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { WebView } from "react-native-webview";

const COLORS = {
  navy: "#102530",
  navySoft: "#183846",
  ink: "#1B2C34",
  muted: "#7C8B90",
  line: "#DDE7E5",
  background: "#F2F6F5",
  surface: "#FFFFFF",
  soft: "#F7FAF9",
  green: "#0F8D70",
  greenDark: "#087258",
  greenPale: "#E5F3ED",
  amber: "#EAA647",
  amberPale: "#FFF2DC",
  bluePale: "#EAF4FA",
  blue: "#3C7FA2",
  danger: "#B95950",
};

const REPORTS_KEY = "sos-zem-android-reports";
const HE_KEY = "sos-zem-android-he";
const JUSTIFICATIVA_URL =
  "https://docs.google.com/forms/d/e/1FAIpQLSdy3dW1q7dAIl4moyctQaX4XcdPaWwlz4kj3LzPlt8OMvDGzg/viewform";

type FormState = {
  osRaf: string;
  ccoCim: string;
  loco: string;
  vagao: string;
  ativoTo: string;
  trem: string;
  local: string;
  km: string;
  data: string;
  hrAcionado: string;
  hrPartida: string;
  hrChegada: string;
  hrInicio: string;
  hrFinal: string;
  hrRetorno: string;
  avariaInformada: string;
  relatoAvaria: string;
  acaoCorretiva: string;
  obs: string;
  download: string;
  fotos: string;
  equipe: string;
};

type SavedReport = FormState & { id: string; savedAt: string };
type HeState = { inicio: string; fim: string; osRaf: string; motivo: string };
type FieldProps = { label: string; value: string; onChangeText: (value: string) => void; placeholder?: string; multiline?: boolean; required?: boolean; keyboardType?: "default" | "numeric" };

const today = () => new Date().toISOString().slice(0, 10).split("-").reverse().join("/");

const initialForm = (): FormState => ({
  osRaf: "", ccoCim: "", loco: "", vagao: "", ativoTo: "", trem: "", local: "", km: "", data: today(),
  hrAcionado: "", hrPartida: "", hrChegada: "", hrInicio: "", hrFinal: "", hrRetorno: "",
  avariaInformada: "", relatoAvaria: "", acaoCorretiva: "", obs: "", download: "", fotos: "", equipe: "",
});

const initialHe = (): HeState => ({ inicio: "", fim: "", osRaf: "", motivo: "" });

function formatDate(value?: string) {
  if (!value) return "Sem data";
  return value;
}

function reportText(form: FormState) {
  return `*ATENDIMENTO MR+T.O - SOS ZEM*\n\n*OS/RAF*: ${form.osRaf || "—"}\n*CCO/CIM*: ${form.ccoCim || "—"}\n*LOCO*: ${form.loco || "—"}\n*VAGÃO*: ${form.vagao || "—"}\n*ATIVO T.O*: ${form.ativoTo || "—"}\n*TREM*: ${form.trem || "—"}\n*LOCAL*: ${form.local || "—"}\n*KM*: ${form.km || "—"}\n*DATA*: ${form.data || "—"}\n*HR ACIONADO*: ${form.hrAcionado || "—"}\n*HR PARTIDA DA BASE*: ${form.hrPartida || "—"}\n*HR CHEGADA*: ${form.hrChegada || "—"}\n*HR INICIO*: ${form.hrInicio || "—"}\n*HR FINAL*: ${form.hrFinal || "—"}\n*HR RETORNO PARA BASE*: ${form.hrRetorno || "—"}\n\n*AVARIA INFORMADA*: ${form.avariaInformada || "—"}\n\n*RELATO DA AVARIA*:\n${form.relatoAvaria || "—"}\n\n*AÇÃO CORRETIVA*:\n${form.acaoCorretiva || "—"}\n\n*OBS*:\n${form.obs || "—"}\n\n*DOWNLOAD*: ${form.download || "—"}\n*FOTOS*: ${form.fotos || "—"}\n*EQUIPE*: ${form.equipe || "—"}`;
}

function Field({ label, value, onChangeText, placeholder, multiline, required, keyboardType = "default" }: FieldProps) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}{required ? <Text style={styles.required}> *</Text> : null}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#AAB8B8"
        multiline={multiline}
        numberOfLines={multiline ? 4 : 1}
        keyboardType={keyboardType}
        style={[styles.input, multiline && styles.textarea]}
        textAlignVertical={multiline ? "top" : "center"}
      />
    </View>
  );
}

function SectionTitle({ eyebrow, title, detail, icon }: { eyebrow: string; title: string; detail: string; icon: ReactNode }) {
  return (
    <View style={styles.sectionTitleRow}>
      <View style={styles.sectionIcon}><Text style={styles.sectionIconText}>{icon}</Text></View>
      <View style={styles.sectionCopy}>
        <Text style={styles.eyebrow}>{eyebrow}</Text>
        <Text style={styles.sectionTitle}>{title}</Text>
        <Text style={styles.sectionDetail}>{detail}</Text>
      </View>
    </View>
  );
}

function ActionButton({ title, onPress, primary, outline, icon }: { title: string; onPress: () => void; primary?: boolean; outline?: boolean; icon: string }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.actionButton, primary && styles.primaryButton, outline && styles.outlineButton, pressed && styles.pressed]}>
      <Text style={[styles.actionIcon, primary && styles.primaryButtonText, outline && styles.outlineButtonText]}>{icon}</Text>
      <Text style={[styles.actionText, primary && styles.primaryButtonText, outline && styles.outlineButtonText]}>{title}</Text>
    </Pressable>
  );
}

export default function App() {
  const [form, setForm] = useState<FormState>(initialForm);
  const [reports, setReports] = useState<SavedReport[]>([]);
  const [he, setHe] = useState<HeState>(initialHe);
  const [heOpen, setHeOpen] = useState(false);
  const [justOpen, setJustOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    Promise.all([AsyncStorage.getItem(REPORTS_KEY), AsyncStorage.getItem(HE_KEY)]).then(([storedReports, storedHe]) => {
      if (storedReports) setReports(JSON.parse(storedReports));
      if (storedHe) setHe(JSON.parse(storedHe));
    }).catch(() => undefined);
  }, []);

  const text = useMemo(() => reportText(form), [form]);
  const update = (key: keyof FormState, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const notify = (value: string) => { setMessage(value); setTimeout(() => setMessage(""), 3000); };

  const saveReport = async () => {
    if (!form.osRaf.trim() || !form.data.trim()) {
      Alert.alert("Campos obrigatórios", "Preencha OS / RAF e DATA antes de salvar.");
      return;
    }
    const next = [{ ...form, id: `${Date.now()}`, savedAt: new Date().toISOString() }, ...reports].slice(0, 30);
    setReports(next);
    await AsyncStorage.setItem(REPORTS_KEY, JSON.stringify(next));
    notify("Relatório salvo neste dispositivo.");
  };

  const newReport = () => { setForm(initialForm()); notify("Novo relatório pronto para preencher."); };

  const loadReport = (saved: SavedReport) => {
    const { id: _id, savedAt: _savedAt, ...savedForm } = saved;
    setForm(savedForm);
    setHistoryOpen(false);
    notify("Relatório carregado para edição.");
  };

  const deleteReport = (id: string) => {
    Alert.alert("Excluir relatório", "Deseja remover este registro do aparelho?", [
      { text: "Cancelar", style: "cancel" },
      { text: "Excluir", style: "destructive", onPress: async () => {
        const next = reports.filter((item) => item.id !== id);
        setReports(next);
        await AsyncStorage.setItem(REPORTS_KEY, JSON.stringify(next));
        notify("Relatório removido.");
      } },
    ]);
  };

  const shareWhatsApp = async () => {
    const url = `whatsapp://send?text=${encodeURIComponent(text)}`;
    try {
      if (await Linking.canOpenURL(url)) await Linking.openURL(url);
      else await Linking.openURL(`https://wa.me/?text=${encodeURIComponent(text)}`);
    } catch {
      await Share.share({ message: text });
    }
  };

  const copyText = async () => { await Clipboard.setStringAsync(text); notify("Texto copiado para a área de transferência."); };

  const pickPhotos = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permissão necessária", "Autorize o acesso às fotos para anexar evidências ao relatório.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsMultipleSelection: true, quality: 0.8 });
    if (!result.canceled) update("fotos", result.assets.map((asset) => asset.fileName || asset.uri.split("/").pop() || "foto").join(", "));
  };

  const saveHe = async () => {
    if (!he.inicio || !he.fim || !he.osRaf || !he.motivo) {
      Alert.alert("Campos obrigatórios", "Preencha todos os campos da Hora Extra.");
      return;
    }
    await AsyncStorage.setItem(HE_KEY, JSON.stringify(he));
    setHeOpen(false);
    notify("Hora extra salva neste dispositivo.");
  };

  return (
    <View style={styles.app}>
      <StatusBar style="light" />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <View style={styles.brandRow}><View style={styles.brandMark}><Text style={styles.brandMarkText}>✦</Text></View><View><Text style={styles.brand}>SOS ZEM</Text><Text style={styles.brandSub}>Central operacional</Text></View></View>
            <View style={styles.livePill}><View style={styles.liveDot} /><Text style={styles.liveText}>LOCAL</Text></View>
          </View>

          <View style={styles.mobileNav}>
            <Pressable style={[styles.navChip, !historyOpen && styles.navChipActive]} onPress={() => { setHistoryOpen(false); }}><Text style={[styles.navChipIcon, !historyOpen && styles.navChipActiveText]}>▦</Text><Text style={[styles.navChipText, !historyOpen && styles.navChipActiveText]}>Atendimento</Text></Pressable>
            <Pressable style={[styles.navChip, historyOpen && styles.navChipActive]} onPress={() => setHistoryOpen(true)}><Text style={[styles.navChipIcon, historyOpen && styles.navChipActiveText]}>◷</Text><Text style={[styles.navChipText, historyOpen && styles.navChipActiveText]}>Histórico {reports.length ? `(${reports.length})` : ""}</Text></Pressable>
            <Pressable style={styles.navChip} onPress={() => setHeOpen(true)}><Text style={styles.navChipIcon}>◌</Text><Text style={styles.navChipText}>Horas Extras</Text></Pressable>
            <Pressable style={styles.navChip} onPress={() => setJustOpen(true)}><Text style={styles.navChipIcon}>↗</Text><Text style={styles.navChipText}>Justificativa</Text></Pressable>
          </View>

          {!historyOpen ? <>
            <View style={styles.hero}>
              <Text style={styles.kicker}>—  REGISTRO DE CAMPO</Text>
              <Text style={styles.heroTitle}>Relatório de<Text style={styles.heroAccent}> atendimento</Text></Text>
              <Text style={styles.heroDescription}>Registre cada detalhe da operação MR+T.O com agilidade, precisão e rastreabilidade.</Text>
              <View style={styles.activeCard}><View style={styles.activeIcon}><Text>▤</Text></View><View><Text style={styles.activeTitle}>Formulário ativo</Text><Text style={styles.activeSub}>Preenchimento em andamento</Text></View></View>
            </View>

            <View style={styles.formCard}>
              <View style={styles.cardTop}><Text style={styles.cardTopText}>ATENDIMENTO MR+T.O</Text><Text style={styles.requiredNote}><Text style={styles.required}>*</Text> campos obrigatórios</Text></View>
              <View style={styles.formSection}>
                <SectionTitle eyebrow="01 · IDENTIFICAÇÃO" title="Dados da ocorrência" detail="Informe os dados principais do atendimento." icon="▣" />
                <View style={styles.twoCol}><Field label="OS / RAF" value={form.osRaf} onChangeText={(value) => update("osRaf", value)} placeholder="Ex.: 123456" required /><Field label="CCO / CIM" value={form.ccoCim} onChangeText={(value) => update("ccoCim", value)} placeholder="Código ou centro" /><Field label="LOCO" value={form.loco} onChangeText={(value) => update("loco", value)} placeholder="Locomotiva" /><Field label="VAGÃO" value={form.vagao} onChangeText={(value) => update("vagao", value)} placeholder="Número do vagão" /><Field label="ATIVO T.O" value={form.ativoTo} onChangeText={(value) => update("ativoTo", value)} placeholder="Ativo / equipamento" /><Field label="TREM" value={form.trem} onChangeText={(value) => update("trem", value)} placeholder="Identificação do trem" /></View>
                <Field label="LOCAL" value={form.local} onChangeText={(value) => update("local", value)} placeholder="Local do atendimento" /><View style={styles.twoCol}><Field label="KM" value={form.km} onChangeText={(value) => update("km", value)} placeholder="Km do atendimento" keyboardType="numeric" /><Field label="DATA" value={form.data} onChangeText={(value) => update("data", value)} placeholder="DD/MM/AAAA" required /></View>
              </View>

              <View style={styles.formSection}>
                <SectionTitle eyebrow="02 · CRONOLOGIA" title="Linha do tempo" detail="Registre os horários para acompanhar a jornada." icon="◷" />
                <View style={styles.twoCol}><Field label="HR ACIONADO" value={form.hrAcionado} onChangeText={(value) => update("hrAcionado", value)} placeholder="00:00" /><Field label="HR PARTIDA DA BASE" value={form.hrPartida} onChangeText={(value) => update("hrPartida", value)} placeholder="00:00" /><Field label="HR CHEGADA" value={form.hrChegada} onChangeText={(value) => update("hrChegada", value)} placeholder="00:00" /><Field label="HR INÍCIO" value={form.hrInicio} onChangeText={(value) => update("hrInicio", value)} placeholder="00:00" /><Field label="HR FINAL" value={form.hrFinal} onChangeText={(value) => update("hrFinal", value)} placeholder="00:00" /><Field label="HR RETORNO PARA BASE" value={form.hrRetorno} onChangeText={(value) => update("hrRetorno", value)} placeholder="00:00" /></View>
              </View>

              <View style={styles.formSection}>
                <SectionTitle eyebrow="03 · DIAGNÓSTICO" title="Avaria e ação" detail="Descreva o cenário encontrado e a solução aplicada." icon="✦" />
                <Field label="AVARIA INFORMADA" value={form.avariaInformada} onChangeText={(value) => update("avariaInformada", value)} placeholder="O que foi informado no acionamento?" /><Field label="RELATO DA AVARIA" value={form.relatoAvaria} onChangeText={(value) => update("relatoAvaria", value)} placeholder="Descreva sintomas, condições e evidências..." multiline /><Field label="AÇÃO CORRETIVA" value={form.acaoCorretiva} onChangeText={(value) => update("acaoCorretiva", value)} placeholder="Descreva o procedimento realizado..." multiline /><Field label="OBS" value={form.obs} onChangeText={(value) => update("obs", value)} placeholder="Observações adicionais" multiline />
              </View>

              <View style={styles.formSection}>
                <SectionTitle eyebrow="04 · EVIDÊNCIAS" title="Anexos e equipe" detail="Adicione referências para fechar o registro." icon="▧" />
                <Field label="DOWNLOAD" value={form.download} onChangeText={(value) => update("download", value)} placeholder="Link ou referência de download" />
                <View style={styles.field}><Text style={styles.label}>FOTOS</Text><Pressable onPress={pickPhotos} style={({ pressed }) => [styles.photoButton, pressed && styles.pressed]}><Text style={styles.photoButtonIcon}>▧</Text><Text style={styles.photoButtonText}>{form.fotos || "Selecionar fotos da galeria"}</Text></Pressable><Text style={styles.hint}>Os nomes dos arquivos ficam registrados no relatório.</Text></View>
                <Field label="EQUIPE" value={form.equipe} onChangeText={(value) => update("equipe", value)} placeholder="Nome ou matrícula da equipe" />
              </View>

              <View style={styles.actions}><ActionButton title="Novo relatório" icon="＋" onPress={newReport} /><View style={styles.actionRow}><ActionButton title="Copiar" icon="□" onPress={copyText} /><ActionButton title="WhatsApp" icon="◉" onPress={shareWhatsApp} outline /><ActionButton title="Salvar" icon="✓" onPress={saveReport} primary /></View></View>
            </View>
          </> : <View style={styles.historyPage}>
            <Text style={styles.kicker}>—  ARQUIVO LOCAL</Text><View style={styles.historyTitleRow}><Text style={styles.pageTitle}>Relatórios recentes</Text><Text style={styles.countBadge}>{reports.length} {reports.length === 1 ? "registro" : "registros"}</Text></View>
            {reports.length === 0 ? <View style={styles.empty}><View style={styles.emptyIcon}><Text>▣</Text></View><Text style={styles.emptyTitle}>Nenhum relatório salvo ainda</Text><Text style={styles.emptyText}>Quando você salvar um atendimento, ele aparecerá aqui neste aparelho.</Text></View> : reports.map((item) => <View key={item.id} style={styles.reportRow}><View style={styles.reportIcon}><Text>▤</Text></View><View style={styles.reportMain}><Text style={styles.reportOs}>{item.osRaf || "Sem OS / RAF"}</Text><Text style={styles.reportMeta}>{item.local || "Local não informado"} · {formatDate(item.data)}</Text></View><Pressable onPress={() => loadReport(item)} style={styles.rowButton}><Text>↗</Text></Pressable><Pressable onPress={() => deleteReport(item.id)} style={[styles.rowButton, styles.deleteButton]}><Text>×</Text></Pressable></View>)}
          </View>}

          <Text style={styles.footer}>Relatórios de atendimento · SOS ZEM</Text>
        </ScrollView>
      </KeyboardAvoidingView>

      {message ? <View style={styles.toast}><View style={styles.toastCheck}><Text>✓</Text></View><Text style={styles.toastText}>{message}</Text></View> : null}

      <Modal visible={heOpen} transparent animationType="fade" onRequestClose={() => setHeOpen(false)}>
        <View style={styles.modalBackdrop}><View style={styles.modalCard}><View style={styles.modalHeader}><View><Text style={styles.eyebrow}>ATALHO OPERACIONAL</Text><Text style={styles.modalTitle}>Horas Extras</Text></View><Pressable onPress={() => setHeOpen(false)} style={styles.closeButton}><Text>×</Text></Pressable></View><Text style={styles.modalDescription}>Registre o período e o motivo da hora extra vinculada ao atendimento.</Text><Field label="INÍCIO DA HE" value={he.inicio} onChangeText={(value) => setHe({ ...he, inicio: value })} placeholder="DD/MM/AAAA HH:MM" /><Field label="FIM DA HE" value={he.fim} onChangeText={(value) => setHe({ ...he, fim: value })} placeholder="DD/MM/AAAA HH:MM" /><Field label="OS / RAF" value={he.osRaf} onChangeText={(value) => setHe({ ...he, osRaf: value })} placeholder="OS vinculada" /><Field label="MOTIVO DA HE" value={he.motivo} onChangeText={(value) => setHe({ ...he, motivo: value })} placeholder="Descreva o motivo da hora extra..." multiline /><View style={styles.modalActions}><ActionButton title="Cancelar" icon="×" onPress={() => setHeOpen(false)} /><ActionButton title="Salvar HE" icon="✓" onPress={saveHe} primary /></View></View></View>
      </Modal>

      <Modal visible={justOpen} animationType="slide" onRequestClose={() => setJustOpen(false)}>
        <View style={styles.webModal}><View style={styles.webHeader}><View><Text style={styles.eyebrow}>FORMULÁRIO EXTERNO</Text><Text style={styles.webTitle}>Justificativa de Horas Extras</Text></View><Pressable onPress={() => setJustOpen(false)} style={styles.closeButton}><Text>×</Text></Pressable></View><WebView source={{ uri: JUSTIFICATIVA_URL }} style={styles.webview} startInLoadingState /><Pressable style={styles.openExternal} onPress={() => Linking.openURL(JUSTIFICATIVA_URL)}><Text style={styles.openExternalText}>Abrir no navegador ↗</Text></Pressable></View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  app: { flex: 1, backgroundColor: COLORS.background },
  flex: { flex: 1 },
  scrollContent: { paddingBottom: 34 },
  header: { backgroundColor: COLORS.navy, paddingTop: 52, paddingHorizontal: 20, paddingBottom: 21, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandMark: { width: 38, height: 38, borderRadius: 11, backgroundColor: COLORS.green, alignItems: "center", justifyContent: "center" },
  brandMarkText: { color: "#FFF", fontSize: 22 },
  brand: { color: "#FFF", fontSize: 17, fontWeight: "800", letterSpacing: 0.5 },
  brandSub: { color: "#91A7A8", fontSize: 10, marginTop: 2 },
  livePill: { flexDirection: "row", alignItems: "center", backgroundColor: "rgba(255,255,255,.09)", paddingHorizontal: 10, paddingVertical: 7, borderRadius: 20 },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#54CBA3", marginRight: 6 },
  liveText: { color: "#C8D9D8", fontSize: 9, letterSpacing: 1 },
  mobileNav: { backgroundColor: COLORS.navy, paddingHorizontal: 14, paddingBottom: 15, flexDirection: "row", gap: 7 },
  navChip: { flex: 1, minHeight: 48, borderRadius: 9, paddingHorizontal: 7, justifyContent: "center", alignItems: "center", backgroundColor: "rgba(255,255,255,.055)" },
  navChipActive: { backgroundColor: COLORS.green },
  navChipIcon: { color: "#9EB3B4", fontSize: 15, marginBottom: 3 },
  navChipText: { color: "#AFC0C0", fontSize: 9, textAlign: "center" },
  navChipActiveText: { color: "#FFF" },
  hero: { paddingHorizontal: 20, paddingTop: 30, paddingBottom: 23 },
  kicker: { color: COLORS.green, fontSize: 10, fontWeight: "700", letterSpacing: 1.5 },
  heroTitle: { color: COLORS.navy, fontSize: 38, lineHeight: 42, fontWeight: "800", letterSpacing: -1.3, marginTop: 12 },
  heroAccent: { color: COLORS.green },
  heroDescription: { color: COLORS.muted, fontSize: 12, lineHeight: 18, marginTop: 10, maxWidth: 350 },
  activeCard: { flexDirection: "row", alignItems: "center", alignSelf: "flex-start", padding: 11, marginTop: 18, borderRadius: 10, backgroundColor: "#E8F2EE", borderWidth: 1, borderColor: "#D2E8DE" },
  activeIcon: { width: 32, height: 32, borderRadius: 9, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.greenPale, marginRight: 9 },
  activeTitle: { color: "#41635B", fontWeight: "700", fontSize: 11 },
  activeSub: { color: "#8BA39E", fontSize: 9, marginTop: 3 },
  formCard: { marginHorizontal: 14, borderRadius: 15, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: "#E2EBE8", overflow: "hidden", shadowColor: "#193D48", shadowOpacity: 0.08, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 2 },
  cardTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: "#EDF2F0" },
  cardTopText: { color: "#7C8C8D", fontSize: 9, letterSpacing: 1 },
  requiredNote: { color: "#9BA9A9", fontSize: 9 },
  formSection: { padding: 21, borderBottomWidth: 1, borderBottomColor: "#EDF2F0" },
  sectionTitleRow: { flexDirection: "row", alignItems: "flex-start", marginBottom: 21 },
  sectionIcon: { width: 34, height: 34, borderRadius: 10, backgroundColor: "#ECF7F2", borderWidth: 1, borderColor: "#CDE8DC", alignItems: "center", justifyContent: "center", marginRight: 11 },
  sectionIconText: { color: COLORS.green, fontSize: 17, fontWeight: "700" },
  sectionCopy: { flex: 1 },
  eyebrow: { color: COLORS.green, fontSize: 9, fontWeight: "700", letterSpacing: 1.3 },
  sectionTitle: { color: COLORS.navy, fontSize: 18, fontWeight: "800", marginTop: 4 },
  sectionDetail: { color: "#96A3A4", fontSize: 10, marginTop: 4, lineHeight: 15 },
  twoCol: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  field: { marginBottom: 15 },
  twoColField: { width: "48%" },
  label: { color: "#657579", fontSize: 9, fontWeight: "700", letterSpacing: 0.7, marginBottom: 7 },
  required: { color: COLORS.green },
  input: { height: 42, borderRadius: 8, borderWidth: 1, borderColor: COLORS.line, backgroundColor: "#FBFCFB", color: COLORS.ink, paddingHorizontal: 11, fontSize: 12 },
  textarea: { minHeight: 103, paddingTop: 11, lineHeight: 18 },
  hint: { color: "#9AA7A8", fontSize: 9, marginTop: -8, marginBottom: 11 },
  photoButton: { minHeight: 43, flexDirection: "row", alignItems: "center", borderRadius: 8, borderWidth: 1, borderColor: COLORS.line, backgroundColor: COLORS.soft, paddingHorizontal: 12 },
  photoButtonIcon: { color: COLORS.green, fontSize: 18, marginRight: 9 },
  photoButtonText: { flex: 1, color: "#8C9B9C", fontSize: 11 },
  actions: { padding: 16, backgroundColor: "#FBFCFB" },
  actionRow: { flexDirection: "row", gap: 7, marginTop: 9 },
  actionButton: { minHeight: 40, flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 8, borderWidth: 1, borderColor: "#DCE6E3", backgroundColor: COLORS.surface, paddingHorizontal: 12, flex: 1 },
  primaryButton: { backgroundColor: COLORS.green, borderColor: COLORS.green, shadowColor: COLORS.green, shadowOpacity: 0.2, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 2 },
  outlineButton: { backgroundColor: "#F1FAF6", borderColor: "#A9D7C8" },
  actionIcon: { color: "#647679", fontSize: 15, marginRight: 6 },
  actionText: { color: "#647679", fontSize: 10, fontWeight: "700" },
  primaryButtonText: { color: "#FFF" },
  outlineButtonText: { color: COLORS.greenDark },
  pressed: { opacity: 0.76, transform: [{ scale: 0.98 }] },
  historyPage: { padding: 20, minHeight: 500 },
  historyTitleRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 9, marginBottom: 20 },
  pageTitle: { color: COLORS.navy, fontSize: 25, fontWeight: "800", letterSpacing: -0.5 },
  countBadge: { color: "#66817B", backgroundColor: COLORS.greenPale, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 6, fontSize: 9 },
  empty: { borderWidth: 1, borderStyle: "dashed", borderColor: "#CBDCD6", borderRadius: 12, padding: 22, alignItems: "center", backgroundColor: "rgba(255,255,255,.42)" },
  emptyIcon: { width: 42, height: 42, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.greenPale, marginBottom: 10 },
  emptyTitle: { color: "#48635E", fontSize: 12, fontWeight: "700" },
  emptyText: { color: "#8C9B9C", fontSize: 10, textAlign: "center", lineHeight: 15, marginTop: 5 },
  reportRow: { minHeight: 64, flexDirection: "row", alignItems: "center", borderRadius: 11, borderWidth: 1, borderColor: "#E1ECE8", backgroundColor: "#FFF", padding: 10, marginBottom: 8 },
  reportIcon: { width: 35, height: 35, borderRadius: 9, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.greenPale, marginRight: 10 },
  reportMain: { flex: 1 },
  reportOs: { color: "#344B4C", fontSize: 12, fontWeight: "700" },
  reportMeta: { color: "#8D9A9B", fontSize: 9, marginTop: 4 },
  rowButton: { width: 30, height: 30, borderRadius: 7, alignItems: "center", justifyContent: "center", backgroundColor: "#EDF7F3", marginLeft: 6 },
  deleteButton: { backgroundColor: "#FFF1EF" },
  footer: { color: "#9AA7A8", fontSize: 9, textAlign: "center", marginTop: 29 },
  toast: { position: "absolute", left: 16, right: 16, bottom: 22, minHeight: 48, borderRadius: 10, backgroundColor: "#173F3C", flexDirection: "row", alignItems: "center", paddingHorizontal: 12, shadowColor: "#102530", shadowOpacity: 0.25, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 5 },
  toastCheck: { width: 24, height: 24, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.green, marginRight: 9 },
  toastText: { flex: 1, color: "#EAF8F3", fontSize: 11 },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(7,24,30,.65)", alignItems: "center", justifyContent: "center", padding: 18 },
  modalCard: { width: "100%", borderRadius: 15, padding: 20, backgroundColor: "#FFF", maxHeight: "92%" },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  modalTitle: { color: COLORS.navy, fontSize: 22, fontWeight: "800", marginTop: 5 },
  modalDescription: { color: "#7C8B8D", fontSize: 11, lineHeight: 17, marginTop: 15, marginBottom: 18 },
  closeButton: { width: 32, height: 32, borderRadius: 9, borderWidth: 1, borderColor: COLORS.line, alignItems: "center", justifyContent: "center" },
  closeButtonText: { color: "#68787E", fontSize: 22, lineHeight: 25 },
  modalActions: { flexDirection: "row", gap: 8, borderTopWidth: 1, borderTopColor: "#EDF1F0", paddingTop: 16, marginTop: 5 },
  webModal: { flex: 1, paddingTop: 52, backgroundColor: COLORS.background },
  webHeader: { minHeight: 64, paddingHorizontal: 17, paddingBottom: 12, flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", backgroundColor: "#FFF" },
  webTitle: { color: COLORS.navy, fontSize: 19, fontWeight: "800", marginTop: 4 },
  webview: { flex: 1, backgroundColor: "#FFF" },
  openExternal: { backgroundColor: COLORS.green, margin: 12, minHeight: 42, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  openExternalText: { color: "#FFF", fontSize: 11, fontWeight: "700" },
});
