# SOS ZEM Android

Aplicativo Android local para criação de relatórios de atendimento MR+T.O - SOS ZEM.

## Recursos

- Formulário completo de atendimento com identificação, cronologia, avaria, ação corretiva, observações, evidências e equipe.
- Salvamento local no aparelho usando `AsyncStorage`.
- Histórico de relatórios salvos, carregamento para edição e exclusão.
- Seleção de fotos pela galeria do Android.
- Compartilhamento direto via WhatsApp, com fallback para o compartilhamento do Android.
- Menu **Horas Extras**, também salvo localmente.
- Menu **Justificativa de Horas Extras** com o Google Forms aberto dentro do app.

## Testar localmente no Android

```bash
npm install
npx expo start
```

Depois, abra o projeto no Expo Go ou pressione `a` com um emulador Android ativo.

## Gerar APK com EAS Build

O arquivo `eas.json` já contém um perfil `preview` configurado para gerar `.apk` instalável, em vez de `.aab`.

### 1. Instalar ou usar o EAS CLI

Você pode instalar globalmente:

```bash
npm install --global eas-cli
```

Ou usar sempre a versão mais recente sem instalação global:

```bash
npx eas-cli@latest --version
```

Os comandos abaixo usam `npx eas-cli@latest`, que é a opção recomendada para evitar versões antigas.

### 2. Criar ou acessar sua conta Expo

```bash
npx eas-cli@latest login
```

Informe seu usuário/e-mail e senha Expo. Se ainda não tiver conta, crie uma gratuitamente em https://expo.dev/signup.

### 3. Entrar na pasta do projeto

```bash
cd sos-zem-android
```

### 4. Vincular o projeto ao EAS

Execute:

```bash
npx eas-cli@latest build:configure
```

Se o EAS perguntar se deseja criar/vincular um projeto na conta Expo, responda `Y`/`Yes`. O identificador Android já está definido como `br.com.soszem.atendimento`.

Se o comando criar ou substituir um `eas.json`, confirme que o perfil `preview` mantém esta configuração:

```json
{
  "build": {
    "preview": {
      "distribution": "internal",
      "android": {
        "buildType": "apk"
      }
    }
  }
}
```

### 5. Iniciar o build do APK

```bash
npx eas-cli@latest build --platform android --profile preview
```

Na primeira execução, o EAS poderá perguntar sobre credenciais Android. Para um projeto novo, escolha a opção para o EAS gerar e gerenciar uma nova keystore. A keystore ficará armazenada com segurança no EAS.

### 6. Acompanhar o build

O terminal exibirá um link para a página do build. Também é possível consultar depois com:

```bash
npx eas-cli@latest build:list --platform android
```

O build normalmente leva alguns minutos. Quando terminar, abra o link indicado pelo terminal e clique em **Install** ou copie o link do artefato APK.

### 7. Instalar no celular Android

No celular, abra o link do APK recebido. Autorize a instalação de aplicativos desta fonte quando o Android solicitar e conclua a instalação.

Também é possível instalar usando ADB, se estiver configurado:

```bash
adb install caminho/para/o/app.apk
```

O perfil `preview` é para distribuição interna e testes; ele não é o formato recomendado para publicar na Google Play. Para publicação, use o perfil `production`, que gera normalmente um `.aab`.

## Validação realizada

O projeto foi validado com:

```bash
npx tsc --noEmit
npx expo export --platform android
```

Ambos os comandos concluíram com sucesso.
